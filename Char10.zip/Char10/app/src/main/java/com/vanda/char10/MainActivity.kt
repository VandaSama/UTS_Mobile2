package com.vanda.char10

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity(),View.OnClickListener {

    private lateinit var BTNN: Button
    private lateinit var BTNN2: Button

    companion object {
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val charList = listOf<Char>(
            Char(
                R.drawable.gojo,
                "Gojo Satoru",
                "Dari Anime Jujutsu Kaisen"
            ),
            Char(
                R.drawable.itadori,
                "Itadori Yuji",
                "Dari Anime Jujutsu Kaisen"
            ),
            Char(
                R.drawable.nanami,
                "Kento Nanami",
                "Dari Anime Jujutsu Kaisen"
            ),
            Char(
                R.drawable.asta,
                "Asta",
                "Dari Anime Black Clover"
            ),
            Char(
                R.drawable.yuno,
                "Yuno",
                "Dari Anime Black Clover"
            ),
            Char(
                R.drawable.yami,
                "Yami Sukehiro",
                "Dari Anime Black Clover"
            ),
            Char(
                R.drawable.midoriya,
                "Izuku Midoriya",
                "Dari Anime Boku No Hero Academia"
            ),
            Char(
                R.drawable.bakugo,
                "Katsugi Bakugo",
                "Dari Anime Boku No Hero Academia"
            ),
            Char(
                R.drawable.todoroki,
                "Shoto Todoroki",
                "Dari Anime Boku No Hero Academia"
            ),
            Char(
                R.drawable.mineta,
                "Minoru Mineta",
                "Dari Anime Boku No Hero Academia"
            ),

            )

        val recyclerView = findViewById<RecyclerView>(R.id.rv_char)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = CharAdapter(this, charList) {
            val intent = Intent(this, DetailCharActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)


        }


        BTNN = findViewById(R.id.BTN)
        BTNN.setOnClickListener(this)

        BTNN2 = findViewById(R.id.BTN2)
        BTNN2.setOnClickListener(this)


    }
    override fun onClick(v: View?){
        if (v != null){
            when(v.id){
                R.id.BTN -> run {
                    val intentBiasa = Intent(this@MainActivity, profile::class.java)
                    startActivity(intentBiasa)
                }
            }
        }
    }

    fun onTouch(v: View?){
        if (v != null){
            when(v.id){
                R.id.BTN2 -> run {
                    val intentBiasa2 = Intent(this@MainActivity, home::class.java)
                    startActivity(intentBiasa2)
                }
            }
        }
    }
}