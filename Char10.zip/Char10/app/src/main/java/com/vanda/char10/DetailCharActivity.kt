package com.vanda.char10

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailCharActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_char)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val char = intent.getParcelableExtra<Char>(MainActivity.INTENT_PARCELABLE)

        val imgChar = findViewById<ImageView>(R.id.img_item_photo)
        val nameChar = findViewById<TextView>(R.id.tv_item_name)
        val descChar = findViewById<TextView>(R.id.tv_item_description)

        imgChar.setImageResource(char?.imgChar!!)
        nameChar.text = char.nameChar
        descChar.text = char.descChar

    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

}