package com.vanda.char10

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CharAdapter(private val context: Context, private val char: List<Char>, val listener:(Char) -> Unit)
    : RecyclerView.Adapter<CharAdapter.CharViewHolder>(){
    class CharViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val imgChar = view.findViewById<ImageView>(R.id.img_item_photo)
        val nameChar = view.findViewById<TextView>(R.id.tv_item_name)
        val descChar = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(char: Char, listener: (Char) -> Unit) {
            imgChar.setImageResource(char.imgChar)
            nameChar.text = char.nameChar
            descChar.text = char.descChar
            itemView.setOnClickListener{
                listener(char)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharViewHolder {
        return CharViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_char, parent, false)
        )
    }

    override fun getItemCount(): Int = char.size

    override fun onBindViewHolder(holder: CharViewHolder, position: Int) {
        holder.bindView(char[position], listener)
    }

}