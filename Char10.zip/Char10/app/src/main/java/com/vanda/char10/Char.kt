package com.vanda.char10

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Char(
    val imgChar: Int,
    val nameChar: String,
    val descChar: String
) : Parcelable
